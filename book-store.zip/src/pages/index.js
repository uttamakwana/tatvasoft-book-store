import Home from "./Home/Home";
import About from "./About/About";
import NotFound from "./NotFound/NotFound";

export { Home, About, NotFound };
